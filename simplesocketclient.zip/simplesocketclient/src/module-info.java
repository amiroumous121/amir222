/**
 * 
 */
/**
 * @author kali
 *
 */
module simplesocketclient {
}