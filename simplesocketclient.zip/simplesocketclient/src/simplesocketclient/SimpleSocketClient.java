package simplesocketclient;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;


public class SimpleSocketClient {


	 public static void main(String[] args)
	 {
		 
	 String server = "localhost";
	 String path = "/";
	 System.out.println("Loading contents of the URL: "+ server);
	 
	 try 
	 {
		 //define a new socket
		 Socket socket =  new Socket (server,8080);
		 
		 // define the input and output objects to send and received HTTP request and response
		 PrintStream out = new PrintStream (socket.getOutputStream());
		 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		 
		 
		 //Create a HTTP GET request
		  out.println("GET " + path + " HTTP/1.1");
		   out.println("Host: " + server);
            out.println("Accept: */*");
            out.println("User-Agent: Java"); 
            out.println(""); // Important, else the server will expect that there's more into the request.
            out.flush();
		// out.println();
		 
		 for (String line; (line = in.readLine()) != null;) {
                if (line.isEmpty()) break; // Stop when headers are completed. We're not interested in all the HTML.
                System.out.println(line);
            }
	 
		 //read the response from the server
		 String line = in.readLine();
		 while(line != null)
		 {
			 System.out.println(line);
			 line = in.readLine();
		 }
		 //*/
		 in.close();
		 out.close();
		 socket.close();
	 }
	 catch (Exception e)
	 {
		 e.printStackTrace();
	 }
	 
	 }
}

